"""
AWS Lambda Function for Scheduled SQLite Database Preparation
This function is triggered by AWS EventBridge on a schedule and calls the
ExecuteScheduledPreparation API endpoint to initiate SQLite preparation for all configured users.
"""

import json
import urllib3
import os
from datetime import datetime

# Disable SSL warnings if needed (remove in production if using valid certs)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Initialize HTTP client
http = urllib3.PoolManager()

# Configuration - These can be set as Lambda environment variables
API_BASE_URL = os.environ.get('API_BASE_URL', 'http://your-api-url.com')
API_ENDPOINT = '/api/SqliteSchedule/ExecuteScheduledPreparation'
API_KEY = os.environ.get('API_KEY', '')  # Optional: For API authentication
TIMEOUT = 300  # 5 minutes timeout for API call


def lambda_handler(event, context):
    """
    Lambda function handler - triggered by EventBridge

    Args:
        event: EventBridge event data (contains trigger information)
        context: Lambda context object

    Returns:
        dict: Response with status code and execution details
    """

    print(f"Lambda function invoked at: {datetime.utcnow().isoformat()}")
    print(f"Event: {json.dumps(event)}")

    # Extract trigger information from event
    trigger_type = event.get('triggerType', 'scheduled')
    triggered_by = event.get('triggeredBy', 'eventbridge')

    # Construct full API URL
    api_url = f"{API_BASE_URL.rstrip('/')}{API_ENDPOINT}"

    print(f"Calling API: {api_url}")

    # Prepare request payload
    payload = {
        "triggerType": trigger_type,
        "triggeredBy": triggered_by
    }

    # Prepare headers
    headers = {
        'Content-Type': 'application/json'
    }

    # Add API key if configured
    if API_KEY:
        headers['Authorization'] = f'Bearer {API_KEY}'

    try:
        # Make HTTP POST request to API
        response = http.request(
            'POST',
            api_url,
            body=json.dumps(payload),
            headers=headers,
            timeout=TIMEOUT
        )

        # Parse response
        response_data = json.loads(response.data.decode('utf-8'))

        print(f"API Response Status: {response.status}")
        print(f"API Response Data: {json.dumps(response_data)}")

        if response.status == 200:
            # Success
            execution_id = response_data.get('Data', {}).get('ExecutionId')

            return {
                'statusCode': 200,
                'body': json.dumps({
                    'message': 'SQLite scheduled preparation initiated successfully',
                    'executionId': execution_id,
                    'timestamp': datetime.utcnow().isoformat(),
                    'apiResponse': response_data
                })
            }
        else:
            # API returned non-200 status
            print(f"API call failed with status: {response.status}")
            return {
                'statusCode': response.status,
                'body': json.dumps({
                    'message': 'API call failed',
                    'error': response_data,
                    'timestamp': datetime.utcnow().isoformat()
                })
            }

    except urllib3.exceptions.TimeoutError as e:
        # Request timeout
        error_msg = f"API request timed out after {TIMEOUT} seconds"
        print(f"ERROR: {error_msg}")
        print(f"Exception: {str(e)}")

        return {
            'statusCode': 504,
            'body': json.dumps({
                'message': error_msg,
                'error': str(e),
                'timestamp': datetime.utcnow().isoformat()
            })
        }

    except Exception as e:
        # General error
        error_msg = f"Unexpected error occurred: {str(e)}"
        print(f"ERROR: {error_msg}")
        print(f"Exception type: {type(e).__name__}")

        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Internal error in Lambda function',
                'error': str(e),
                'error_type': type(e).__name__,
                'timestamp': datetime.utcnow().isoformat()
            })
        }


# For local testing
if __name__ == "__main__":
    # Test event
    test_event = {
        "triggerType": "manual",
        "triggeredBy": "local-test"
    }

    test_context = {}

    print("=" * 60)
    print("Local Testing")
    print("=" * 60)

    result = lambda_handler(test_event, test_context)

    print("\n" + "=" * 60)
    print("Result:")
    print(json.dumps(result, indent=2))
    print("=" * 60)
